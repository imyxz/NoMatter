﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace JSON
{
    public enum JSONChildrenType
    {
        STRING,
        ARRAY,
        DICTIONARY,
        INT,
        DOUBLE,
        BOOLEAN,
        NULL
    }
}