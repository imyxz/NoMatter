﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CommonClass
{
    public enum MatterPeriodicityType
    {
        OneTime,
        Dayly,
        Weekly,
        Monthly
    }
}